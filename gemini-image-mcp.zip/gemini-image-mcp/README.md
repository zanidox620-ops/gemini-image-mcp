# Gemini Image MCP Server

Ye server Gemini ke image model ko MCP tool ke roop mein expose karta hai,
taaki Claude isse connect karke image generate kar sake.

## Deploy on Render.com (free)

1. Is poore folder ko GitHub repo mein upload karo (`gemini-image-mcp` naam se).
2. Render.com pe login karo -> "New" -> "Web Service".
3. Apna GitHub repo select karo.
4. Settings:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. "Environment" tab mein ek variable add karo:
   - Key: `GEMINI_API_KEY`
   - Value: (apni Google AI Studio API key yaha paste karo)
6. Deploy karo. Kuch minute mein ek URL milega jaise:
   `https://gemini-image-mcp.onrender.com`
7. Us URL ke aage `/mcp` lagao:
   `https://gemini-image-mcp.onrender.com/mcp`
8. Yehi URL Claude.ai -> Settings -> Connectors -> "Add custom connector" mein paste karo.

Bas itna hi - API key kabhi bhi code mein nahi likhi gayi, sirf Render ke
secret Environment Variables mein rakhi jaati hai.
